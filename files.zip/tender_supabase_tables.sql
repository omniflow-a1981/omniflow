-- ══════════════════════════════════════════════
-- OmniFlow — Bid & Tender Module
-- Run in Supabase: Dashboard → SQL Editor → New Query
-- ══════════════════════════════════════════════

CREATE TABLE IF NOT EXISTS eng_div_templates (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id text NOT NULL,
  division_code text NOT NULL,
  overhead_pct numeric DEFAULT 15,
  profit_pct numeric DEFAULT 10,
  updated_at timestamptz DEFAULT now(),
  UNIQUE(company_id, division_code)
);

CREATE TABLE IF NOT EXISTS eng_rate_items (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id text NOT NULL,
  division_code text NOT NULL,
  category text NOT NULL CHECK (category IN ('Labour','Equipment','Material')),
  description text NOT NULL,
  unit text NOT NULL DEFAULT '',
  base_rate numeric DEFAULT 0,
  updated_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS eng_tenders (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  company_id text NOT NULL,
  division_code text NOT NULL,
  tender_name text NOT NULL,
  client text DEFAULT '',
  location text DEFAULT '',
  submission_deadline date,
  doc_fee numeric DEFAULT 0,
  bid_bond numeric DEFAULT 0,
  prep_cost numeric DEFAULT 0,
  location_factor numeric DEFAULT 1.0,
  allowances numeric DEFAULT 0,
  notes text DEFAULT '',
  status text DEFAULT 'active' CHECK (status IN ('draft','active','submitted','won','lost')),
  outcome text DEFAULT '',
  created_by text DEFAULT '',
  created_at timestamptz DEFAULT now()
);

CREATE TABLE IF NOT EXISTS eng_boq_items (
  id uuid DEFAULT gen_random_uuid() PRIMARY KEY,
  tender_id uuid REFERENCES eng_tenders(id) ON DELETE CASCADE,
  section text DEFAULT 'General',
  description text NOT NULL,
  unit text DEFAULT '',
  quantity numeric DEFAULT 0,
  rate_item_id uuid REFERENCES eng_rate_items(id) ON DELETE SET NULL,
  unit_price numeric DEFAULT 0,
  amount numeric DEFAULT 0,
  matched boolean DEFAULT false
);
